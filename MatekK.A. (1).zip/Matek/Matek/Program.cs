﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

namespace Matek
{
    public class Matek
    {
        int a;
        public Matek(int a)
        {
            this.a = a;
        }

        public int Szorzas(int a, int b)
        {
            return a * b;
        }

        public int Osztas(int a, int b)
        {
            return a/b;
        }

    }

    internal class Program
    {
        
        static void Main(string[] args)
        {

        }
    }
}
