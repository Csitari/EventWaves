﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matek.tesztek
{
    internal class Teszt
    {
        Matek m;

        [Test]
        public void SzorzasTest()
        {
            //Matek m = new Matek(4);
            int act = m.Szorzas(4,3);
            Assert.That(12, Is.EqualTo(act));
        }
        [Test]
        public void OsztasTeszt() 
        {
            int act = m.Osztas(12, 2);
            Assert.That(6, Is.EqualTo(act));
        }

        [Test]
        public void ParosTeszt() 
        {
            
        }
    }
}
