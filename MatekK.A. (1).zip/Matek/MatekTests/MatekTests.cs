﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Matek;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matek.Tests
{
    [TestClass()]
    public class MatekTests
    {
        [TestMethod()]
        public void SzorzasTest()
        {
            Matek m = new Matek(3);

            Assert.AreEqual(12, m.Szorzas(3,4));
        }

        [TestMethod()]
        public void OsztasTeszt()
        {
            Matek m = new Matek(4);

            Assert.AreEqual(12, m.Osztas(24,2));
        }
    }
}