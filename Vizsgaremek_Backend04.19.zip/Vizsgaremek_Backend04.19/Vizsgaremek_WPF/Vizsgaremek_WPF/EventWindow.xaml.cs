﻿using System;
using System.Windows;
using MySql.Data.MySqlClient;

namespace Vizsgaremek_WPF
{
    public partial class EventWindow : Window
    {
        private const string connectionString = "server=localhost;database=mydatabase;user=root;password=;sslmode=none";

        public EventWindow()
        {
            InitializeComponent();
            LoadEventsFromDatabase();
        }

        private void LoadEventsFromDatabase()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    string query = "SELECT * FROM events";
                    MySqlCommand command = new MySqlCommand(query, connection);

                    connection.Open();
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt az események lekérdezése során: " + ex.Message);
            }
        }
    }
}
