﻿namespace Vizsgaremek_Backend.Controllers.JWT
{
    public class Token
    {
        public string tokenValue { get; set; }
    }
}
