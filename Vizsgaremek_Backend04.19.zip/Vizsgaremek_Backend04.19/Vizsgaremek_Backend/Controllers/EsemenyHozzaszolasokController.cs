﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Vizsgaremek_Backend.Models;
using Microsoft.EntityFrameworkCore;

namespace Vizsgaremek_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EsemenyHozzaszolasokController : ControllerBase
    {
        private readonly EsemenytarContext _context;

        public EsemenyHozzaszolasokController(EsemenytarContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<EsemenyHozzaszolasok> GetAll()
            //hozzaszolas_id,esemeny_id,hozzaszolo_id helyett ffelhasznalonev,hozzaszolas_szoveg,letrehozva
        {
            return Ok(_context.EsemenyHozzaszolasoks.Include(x => x.Esemeny).Include(x => x.Hozzaszolo).Select(x => new {x.HozzaszolasId,x.EsemenyId,x.HozzaszoloId,Felhasznalonev = x.Hozzaszolo.Felhasznalonev,x.HozzaszolasSzoveg,x.Letrehozva}).ToList());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<EsemenyHozzaszolasok>> Get(Guid id)
        {
            var item = await _context.EsemenyHozzaszolasoks.FindAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            return item;
        }

        [HttpGet("{id},helyetesitett")]
        public async Task<ActionResult<EsemenyHozzaszolasok>> Getxd(Guid id)
        {
            var hozzaszolas = await _context.EsemenyHozzaszolasoks.Include(x => x.Esemeny).Include(x => x.Hozzaszolo).Select(x => new { x.HozzaszolasId, x.EsemenyId, x.HozzaszoloId, Felhasznalonev = x.Hozzaszolo.Felhasznalonev, x.HozzaszolasSzoveg, x.Letrehozva }).FirstOrDefaultAsync(x => x.HozzaszolasId == id);
            if (hozzaszolas == null)
            {
                return NotFound();
            }
            return Ok(hozzaszolas);
        }

        [HttpPost]
        public async Task<ActionResult<EsemenyHozzaszolasok>> Create(EsemenyHozzaszolasok item)
        {
            _context.EsemenyHozzaszolasoks.Add(item);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(Get), new { id = item.HozzaszolasId }, item);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, EsemenyHozzaszolasok item)
        {
            if (id != item.HozzaszolasId)
            {
                return BadRequest();
            }

            _context.Entry(item).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var item = await _context.EsemenyHozzaszolasoks.FindAsync(id);

            if (item == null)
            {
                return NotFound();
            }

            _context.EsemenyHozzaszolasoks.Remove(item);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}

